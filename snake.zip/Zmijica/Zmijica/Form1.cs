﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zmijica
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        const int MAX_ZMIJICA = 300;
        const int DIM = 15;
        PictureBox hrana;
        PictureBox[] zmijica;
        Random r;
        int duzina;

        //1 - desno, 2 - levo, 3-gore, 4-dole
        int smer = 1;

        private void Form1_Load(object sender, EventArgs e)
        {
            r = new Random();
            timer1.Interval = 200;

            hrana = new PictureBox();
            hrana.Size = new Size(DIM, DIM);
            hrana.BackColor = Color.Black;
            hrana.Location = new Point(r.Next(0, pictureBox1.Width - DIM), r.Next(0, pictureBox1.Height - DIM));

            zmijica = new PictureBox[MAX_ZMIJICA];
            zmijica[0] = new PictureBox();
            zmijica[0].Size = new Size(DIM, DIM);
            zmijica[0].BackColor = Color.FromArgb(0, 255, 0);
            zmijica[0].Location = new Point(r.Next(0, pictureBox1.Width - DIM), r.Next(0, pictureBox1.Height - DIM));

            duzina = 1;
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            pictureBox1.Controls.Add(zmijica[0]);
            pictureBox1.Controls.Add(hrana);
            timer1.Start();
        }

        void restart()
        {
            int i;
            for (i = 0; i < duzina; i++)
                pictureBox1.Controls.Remove(zmijica[i]);
            pictureBox1.Controls.Remove(hrana);

            zmijica[0].Location = new Point(r.Next(0, pictureBox1.Width - DIM), r.Next(0, pictureBox1.Height - DIM));
            hrana.Location = new Point(r.Next(0, pictureBox1.Width - DIM), r.Next(0, pictureBox1.Height - DIM));
            duzina = 1;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //Pomeranje cele zmije:
            Point pozicija_poslednje = zmijica[duzina - 1].Location;

            int i;
            for (i = duzina-1; i >0; i--)
                zmijica[i].Location = zmijica[i-1].Location;

            switch (smer)
            {
                case 1:
                    zmijica[0].Left += DIM;
                    break;
                case 2:
                    zmijica[0].Left -= DIM;
                    break;
                case 3:
                    zmijica[0].Top -= DIM;
                    break;
                case 4:
                    zmijica[0].Top += DIM;
                    break;
            }

            //Provera da li je izasla napolje
            if (zmijica[0].Left < 0 || zmijica[0].Left + DIM > pictureBox1.Width ||
                zmijica[0].Top < 0 || zmijica[0].Top > pictureBox1.Height)
            {
                //kraj igre
                timer1.Stop();
                MessageBox.Show("Kraj igre!");
                restart();
            }

            //Provera da li je zmijica udarila sama u sebe
            for (i = 1; i < duzina; i++)
            {
                if (zmijica[0].Bounds.IntersectsWith(zmijica[i].Bounds))
                {
                    //kraj igre
                    timer1.Stop();
                    MessageBox.Show("Kraj igre!");
                    restart();
                }
            }

            //Provera da li je zmijica pojela hranu
            if (zmijica[0].Bounds.IntersectsWith(hrana.Bounds))
            {
                zmijica[duzina] = new PictureBox();
                zmijica[duzina].Size = new Size(DIM, DIM);
                zmijica[duzina].Location = pozicija_poslednje;
                zmijica[duzina].BackColor = Color.FromArgb(5*duzina, 200, 5*duzina);
                pictureBox1.Controls.Add(zmijica[duzina]);
                duzina++;
                hrana.Location = new Point(r.Next(0, pictureBox1.Width - DIM), r.Next(0, pictureBox1.Height - DIM));
            }
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Right:
                    smer = 1; break;
                case Keys.Left:
                    smer = 2; break;
                case Keys.Up:
                    smer = 3; break;
                case Keys.Down:
                    smer = 4; break;
            }
        }
    }
}
